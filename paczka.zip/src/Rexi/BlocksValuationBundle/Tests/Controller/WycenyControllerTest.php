<?php

namespace Rexi\BlocksValuationBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class WycenyControllerTest extends WebTestCase
{
}
